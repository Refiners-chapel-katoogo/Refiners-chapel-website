REFINERS CHAPEL KATOOGO WEBSITE — STARTER VERSION

Preview:
1. Extract the ZIP file.
2. Open index.html in a web browser.

Files:
- index.html: the responsive website.
- assets/refiners-chapel-logo.jpg: logo supplied for the website.
- assets/mission-vision-constitution.jpg: supplied constitution artwork used as a subtle hero background.

Before publishing, please replace the editable contact placeholders in index.html with:
- Full church address / directions
- Phone number and email
- Service days and times
- Social media links

This is a static website starter. To make it publicly accessible, upload the extracted folder to a hosting provider or connect it to your domain.
